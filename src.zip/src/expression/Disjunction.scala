package expression

import context._
import value._

/*
Conjunction (&&) and disjunction (||) use a form of lazy execution called short-circuit execution—execute operands from left-to-right until the answer is known, then stop executing operands. In both examples the expression x was never executed.
We know this because executing x produces an undefined identifier error.
disjunction ::= expression ~ ("||" ~ expression)*
*/
case class Disjunction(val operands: List[Expression]) extends SpecialForm {
  def execute(env: Environment) = {
    var result = false
    for(exp <- operands if !result) {
      val arg = exp.execute(env)
      if (!arg.isInstanceOf[Boole]) throw new TypeException("Disjunction operands must be Booles")
      if (arg == Boole(false))result = arg.asInstanceOf[Boole].value
    }
    Boole(result)
  }
}


/*
-> 3 < 4 && 2 == 1 && x
false
-> 2 == 1 || 3 < 4 || x
true
-> if (3 < 4) 3 + 4 else x
7
-> x
Undefined identifier: x
 */