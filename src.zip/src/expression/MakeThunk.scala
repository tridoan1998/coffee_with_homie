package expression

import context._
import value._

case class MakeThunk(val exp: Expression) extends SpecialForm{
  override def execute(env: Environment): Value = Thunk(exp, env)
}