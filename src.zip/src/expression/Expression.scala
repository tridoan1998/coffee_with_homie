package expression

import value.Value
import context.Environment

//abstract class, hold execute method for everything class that want implement it
trait Expression {
  def execute(env: Environment): Value
}