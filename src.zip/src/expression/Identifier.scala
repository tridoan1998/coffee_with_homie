package expression

import context.Environment
import value._

//identifier the type of the object
case class Identifier(val name: String) extends Expression {

  override def toString = name

  def hashcode = this.toString.hashCode

  override def equals(other: Any) =
    if(!other.isInstanceOf[Identifier]) false
    else this.name == other.asInstanceOf[Identifier].name

  def execute(env: Environment) = env(this) match{
    case value: Value => value
  }
}