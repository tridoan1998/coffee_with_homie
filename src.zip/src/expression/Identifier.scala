package expression

import context.Environment
import value._

//identifier the type of the object
//P.S. Make sure Identifier.execute(env) is calling env(this) i.e., env.apply(this)) instead of the code presented in class for Jedi 1.0.
case class Identifier(val name: String) extends Expression {

  override def toString = name

  def hashcode = this.toString.hashCode

  override def equals(other: Any) =
    if(!other.isInstanceOf[Identifier]) false
    else this.name == other.asInstanceOf[Identifier].name

  //for Jedi 1.0
  //def execute(env: Environment) = env(this) match{
  //  case value: Value => value
  //}

  //for Jedi 2.0
  /*
  When executing an identifier we still need to produce an ordinary value.
   If the identifier is bound to a thunk or a text, then it must first be thawed.
    To thaw a thunk we simply call its inherited apply method: thunk().
    If the identifier is bound to a text, then the expression must be extracted and executed.
   */
  def execute(env: Environment) = env(this) match{
    case thunk: Thunk => thunk()
    case text: Text   => text(env)
    case value: Value => value
  }
}