package expression

import context._
import value._

/*
Similarly conditionals (if/else) use a form of lazy execution called conditional execution—execute the condition.
If it's true, execute the consequent and ignore the alternative. If it's false, execute the alternative (if it's not null, if it is, return Notification.UNSPECIFIED) and ignore the consequent.
 conditional ::= "if" ~ "(" ~ expression ~ ")" ~ expression ~ ("else" ~ expression)?

 */
case class Conditional(val condition:Expression,val consequent:Expression,val alternative:Expression = null) extends SpecialForm with Expression{
  override def execute(env: Environment): Value = {
    var result = true
    if(condition.execute(env) == Boole(true))
    {
      consequent.execute(env)
    }
    else {  if(alternative == null) Notification.UNSPECIFIED else alternative.execute(env)
    }
  }
}