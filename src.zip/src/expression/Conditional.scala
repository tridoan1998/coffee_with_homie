package expression

import context._
import value._

/*
Similarly conditionals (if/else) use a form of lazy execution called conditional execution—execute the condition.
If it's true, execute the consequent and ignore the alternative. If it's false, execute the alternative (if it's not null, if it is, return Notification.UNSPECIFIED) and ignore the consequent.
 conditional ::= "if" ~ "(" ~ expression ~ ")" ~ expression ~ ("else" ~ expression)?

 */
case class Conditional(val cond: Expression, val cons: Expression, val alter: Expression = null) extends SpecialForm {
  def execute(env: Environment): Value = {
    if(cond.execute(env) == Boole(true)) cons.execute(env)
    else{
      if(alter == null) Notification.UNSPECIFIED
      else alter.execute(env)
    }
  }
}