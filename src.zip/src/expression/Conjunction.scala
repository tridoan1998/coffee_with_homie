package expression

import context._
import value._

/*
Conjunction (&&) and disjunction (||) use a form of lazy execution called short-circuit execution—execute operands from left-to-right until the answer is known, then stop executing operands. In both examples the expression x was never executed.
We know this because executing x produces an undefined identifier error.
conjunction ::= expression ~ ("&&" ~ expression)*

 */
case class Conjunction(val operands: List[Expression]) extends SpecialForm {
  def execute(env: Environment): Value = {
    var answer = true
    for (e <- operands if answer != false) {
      e.execute(env) match {
        case Boole(value) => {

          if (value) answer = true

        }
      }
    }
    Boole(answer)
  }
}


/*
-> 3 < 4 && 2 == 1 && x
false
-> 2 == 1 || 3 < 4 || x
true
-> if (3 < 4) 3 + 4 else x
7
-> x
Undefined identifier: x
 */