package expression

import value._
import context._

case class FunCall(val operator: Identifier, val operands: List[Expression]) extends Expression {
  /*
    we turns the list of expressions into a list of values
    The operands may themselves be function calls or any other type of expression.
    The parser converts an infix expressions like 3 + 4 into the FunCall add(3, 4).
    FunCall.execute begins by eagerly executing all of its operands. This produces a list of values called arguments.
    Jedi 1.0 does not have user-defined functions (i.e., lambdas). All functions are implemented in the alu.
    FunCall.execute calls alu.execute(operator, arguments).
   */
  override def execute(env: Environment): Value = {
    {
      val args:List[Value] = operands.map(_.execute(env))
      try
      {
        alu.execute(operator,args)
      }
    }
  }
}