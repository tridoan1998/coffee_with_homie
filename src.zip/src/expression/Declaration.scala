package expression

import value._
import context._

//declaration ::= "def" ~ identifier ~ "=" ~ expression
case class Declaration(val iden: Identifier, val exp: Expression) extends SpecialForm {
  //Declaration.execute(env) adds a new row to env, then returns OK.
  def execute(env: Environment): Value = {
    val result = exp.execute(env)
    env.put(iden, result)
    Notification.DONE
  }
}

/*
-> def pi = 3.14
ok
-> def e = 2.7
ok
-> def pie = pi * e
ok
-> pie
8.478000000000002
 */