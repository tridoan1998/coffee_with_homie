package context

import scala.util.parsing.combinator._
import expression.Identifier

class JediException(gripe: String = "Jedi error ") extends Exception(gripe)
class UndefinedException(name: Identifier) extends JediException("Undefined identifier: " + name)
class TypeException(gripe: String = "Type Error") extends JediException(gripe)
class IllegalValueException(gripe: String = "Illegal Value") extends JediException(gripe)
class SyntaxException(val result: Parsers#Failure = null) extends JediException("Syntax error")

/*
-> x
Undefined identifier: x   // undefined exception
-> 2 + true
Numeric operand required  // type exception
-> 3 / 0
Divide by 0!              // illegal value exception
-> 3 +                    // syntax exception
context.SyntaxException: Syntax error
end of input expected
line # = 1
column # = 3
token = +
->
 */
