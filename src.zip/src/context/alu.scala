package context

import value._
import expression._

//implemented all of the ALU operations
object alu {

  def execute(opcode: Identifier, args: List[Value]): Value = opcode.name match {
    case "add" => add(args)
    case "mul" => mul(args)
    case "sub" => sub(args)
    case "div" => div(args)
    case "less" => less(args)
    case "more" => more(args)
    case "equals" => equals(args)
    case "unequals" => unequals(args)
    case "not" => not(args)
    // variables
    case "dereference" => dereference(args)
    case "var" => makeVar(args)
    // primitive I/O ops:
    case "write" => write(args)
    // case "prompt" => prompt(args)
    // case "read" => read(args)
    // store ops
    /*
    case "store" => store(args)
    case "put" => put(args)
    case "rem" => rem(args)
    case "contains" => contains(args)
    case "map" => map(args)
    case "filter" => filter(args)
    case "get" => get(args)
    case "addLast" => addLast(args)
    case "size" => size(args)
    */
    case _ => throw new UndefinedException(opcode)
  }

  private def add(args: List[Value]): Value = {

    def helper(result: Addable, unseen: List[Value]): Addable =
      if(unseen == Nil) result
      else helper(result + unseen.head, unseen.tail)

    if(args.size < 2) throw new TypeException("2 or more inputs required by +")
    args(0) match {
      case n: Addable => helper(args(0).asInstanceOf[Addable], args.tail )
      case _ => throw new TypeException("Inputs to + must be addable")
    }
  }

  private def mul(args: List[Value]): Numeric = {

    def helper(result: Numeric, unseen: List[Value]): Numeric =
      if(unseen == Nil) result
      else helper(result * unseen.head, unseen.tail)

    if(args.size < 2) throw new TypeException("2 or more inputs required by +")
    args(0) match {
      case n: Numeric => helper(args(0).asInstanceOf[Numeric], args.tail )
      case _ => throw new TypeException("Inputs to + must be addable")
    }
  }

  private def sub(args: List[Value]): Numeric = {

    def helper(result: Numeric, unseen: List[Value]): Numeric =
      if(unseen == Nil) result
      else helper(result - unseen.head, unseen.tail)

    if(args.size < 2) throw new TypeException("2 or more inputs required by +")
    args(0) match {
      case n: Numeric => helper(args(0).asInstanceOf[Numeric], args.tail )
      case _ => throw new TypeException("Inputs to + must be addable")
    }
  }

  private def div(args: List[Value]): Numeric = {

    def helper(result: Numeric, unseen: List[Value]): Numeric =
      if(unseen == Nil) result
      else helper(result / unseen.head, unseen.tail)

    if(args.size < 2) throw new TypeException("2 or more inputs required by +")
    args(0) match {
      case n: Numeric => helper(args(0).asInstanceOf[Numeric], args.tail )
      case _ => throw new TypeException("Inputs to + must be addable")
    }
  }
  //less method called when <
  private def less(args: List[Value]): Value = {
    if(args.size != 2) throw new TypeException("2 inputs required by <")
    if(!args(0).isInstanceOf[Ordered[Value]]) throw new TypeException("Inputs to < must be orderable")
    Boole(args(0).asInstanceOf[Ordered[Value]] < args(1))
  }

  //called when ==
  private def same(args: List[Value]): Value = {
    if(args.size != 2) throw new TypeException("2 inputs required by <")
    if(!args(0).isInstanceOf[Ordered[Value]]) throw new TypeException("Inputs to < must be orderable")
    Boole(args(0).asInstanceOf[Ordered[Value]] == args(1))
  }

  //called when >
  private def more(args: List[Value]): Value = {
    if(args.size != 2) throw new TypeException("2 inputs required by <")
    if(!args(0).isInstanceOf[Ordered[Value]]) throw new TypeException("Inputs to < must be orderable")
    Boole(args(0).asInstanceOf[Ordered[Value]] > args(1))
  }

  //called when !=
  private def unequals(args: List[Value]): Value = {
    if(args.size != 2) throw new TypeException("2 inputs required by <")
    if(!args(0).isInstanceOf[Ordered[Value]]) throw new TypeException("Inputs to < must be orderable")
    Boole(args(0).asInstanceOf[Ordered[Value]] != args(1))
  }

  //called when not
  private def not(args: List[Value]): Value = {
    if(args.length != 1) throw new TypeException("2 inputs required by <")
    if(args(0).isInstanceOf[Boole]){
      if(args(0) == Boole(true)) Boole(false)
      else Boole(true)
    }
    else throw new TypeException("Not a boole!")
  }
}