package value

import expression._
import context._

case class Closure( params: List[Identifier],  body: Expression, defEnv: Environment) extends Value {

  //override def equals(obj: Any): Boolean = super.equals(obj)

  //override def apply(args: List[Value]): Value = super.apply(args)

  //override def hashCode(): Int = super.hashCode()

  override def toString="closure"

  def apply(args: List[Value], callEnv: Environment = null) = {

    val tempEnv = if (flags.staticScope) new Environment(defEnv) else new Environment(callEnv)
    tempEnv.bulkPut(params, args)
    //bind using bulkput
    body.execute(tempEnv)

  }

}
