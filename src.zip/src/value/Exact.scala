package value

import context.{IllegalValueException, TypeException}
import expression.Literal

//Orderables
case class Exact(var value:Int) extends Numeric with Ordered[Value] with Addable {

  override def toString: String = value.toString

  override def hashCode = this.toString.##

  def +(other: Value): Numeric =
    other match {
      case x: Inexact => Inexact(this.value.toDouble + x.value)
      case x: Exact => Exact(this.value + x.value)
      case _ => throw new TypeException("Numeric operand required")
    }

  def unary_(): Numeric = Exact(-this.value)
  def unary_-(): Numeric = Exact(-this.value)

  override def compare(other: Value): Int = {
    other match {
      case x: Inexact => value.toDouble.compare(x.value)
      case x: Exact => value.compare(x.value)
      case _ => throw new TypeException("Arguments must be comparable")
    }
  }

  override def equals(other: Any): Boolean = {
    other match {
      case x: Inexact => x.isInstanceOf[Inexact] && x.value == this.value.toDouble
      case x: Exact => x.isInstanceOf[Exact] && x.value == this.value
      case _ => false
    }
  }


  def -(other: Value): Numeric =
    other match {
      case x: Inexact => Inexact(this.value.toDouble - x.value)
      case x: Exact => Exact(this.value - x.value)
      case _ => throw new TypeException("Numeric operand required")
    }

  def *(other: Value): Numeric =
    other match {
      case x: Inexact => Inexact(this.value.toDouble * x.value)
      case x: Exact => Exact(this.value * x.value)
      case _ => throw new TypeException("Numeric operand required")
    }

  def /(other:Value):Numeric = other match {
    case x: Exact => if(x.value == 0) throw new IllegalValueException("Divide by 0!") else Exact(this.value / x.value)
    case x:Inexact => if(x.value == 0) throw new IllegalValueException("Divide by 0!") else Inexact(this.value / x.value)
  }


}

/*
All of the concrete classes (Boole, Chars, Exact, and Inexact) are value classes in the sense that they need overrides of equals, toString, and hashCode.

Instances of Chars, Exact, and Inexact can be compared to other values, throwing exceptions if the other values don't make sense:

-> "abc" < "def"
true
-> "abc" == "abc"
true
-> 23 < 3.14
false
-> 2.9 < 100
true
-> 0 < true
Arguments must be comparable

Exact and Inexact are Jedi's version of integers and floating-point numbers, respectively. Exacts encapsulate the Scala Int they represent, and Inexacts encapsulate the Scala Double they represent. They are numeric and ordered (comparable). Notice that exacts automatically coerce (i.e. convert) themselves into inexacts when they appear in a context where an inexact was expected:

-> 3 + 5
8
-> 3 + 5.0
8.0
-> 3.0 + 5
8.0
-> 3 / 5
0
-> 3.0 / 5
0.6
-> 3.0 + 5.0
8.0
 */