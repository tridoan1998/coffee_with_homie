package value
import context.{Environment, TypeException}

//Orderables, Adding Strings to Things
case class Chars(var value:String) extends Addable with Ordered[Value]{

  override def compare(other: Value): Int = other match {
    case x: Chars => this.value.compare(other.toString)
    case  _=> throw new TypeException("Must be comparable")
  }

  //override def execute(env: Environment): Value = this
  override def toString = value;

  override def equals(other:Any): Boolean = other match {
    case x: Chars => x.isInstanceOf[Chars] && x.value == this.value
    case _ => throw new TypeException("Must be comparable")
  }

  override def hashCode = this.toString.##

  def size(): Exact = Exact(this.value.size)

  def subChars(to:Exact,from:Exact) = Chars( this.value.substring(to.value,from.value))

  override def +(other: Value): Addable =  Chars(this.value + other.toString)
}

/*
All of the concrete classes (Boole, Chars, Exact, and Inexact) are value classes in the sense that they need overrides of equals, toString, and hashCode.

Instances of Chars, Exact, and Inexact can be compared to other values, throwing exceptions if the other values don't make sense:

-> "abc" < "def"
true
-> "abc" == "abc"
true
-> 23 < 3.14
false
-> 2.9 < 100
true
-> 0 < true
Arguments must be comparable

Jedi strings are called Chars. (I decided not to have a Char type in Jedi.) An instance of Chars encapsulates the Scala string it represents. Adding Chars means appending or concatenation:

-> "abc" + "def"
abcdef
-> "abc" + 100
abc100
-> "abc" + 3.14
abc3.14
-> "abc" + false
abcfalse
 */