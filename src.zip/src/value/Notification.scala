package value


/*
6. A notification encapsulates some message such as "done" or "ok".
 Complete the implementation of the Notification class. Add a companion object
  with an apply method and pre-defined notifications OK, DONE, and UNSPECIFIED.
 */
class Notification(val name: String) extends Value {
  override def equals(obj: Any): Boolean = super.equals(obj)
  override def hashCode(): Int = super.hashCode()
  override def toString = name
}

object Notification{

  val Ok = new Notification("OK")
  val DONE = new Notification("ok")
  val UNSPECIFIED = new Notification("UNSPECIFIED")

  def apply(name: String) = new Notification(name: String)
}
