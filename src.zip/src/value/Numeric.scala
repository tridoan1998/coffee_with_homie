package value

trait Numeric extends Addable {
  //things that can be combined using +, *, -, / and can be negated
  //def +(other: Value): Numeric
  def *(other: Value): Numeric
  def -(other: Value): Numeric
  def /(other: Value): Numeric
  def unary_-(): Numeric
}

/*
I've introduced two new value traits: Addable (things that can be combined using +)
and Numeric (things that can be combined using +, *, -, / and can be negated).

-> 3 * 2.5
7.5
-> -67
-67
-> 5 / 3
1
-> 5.0 / 3
1.6666666666666667
-> "bat" + "man"
batman
-> "2 + 2 = " + 4
2 + 2 = 4
-> true + false
Inputs to + must be addable
 */