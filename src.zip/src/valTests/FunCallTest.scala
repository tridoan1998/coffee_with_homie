package valTests

import expression._
import context._
import value._

//given from lecture to perform test
object FunCallTest extends App {
  val globalEnvironment = new Environment
  val operands = List(Exact(6), Exact(7))
  var exp = FunCall(Identifier("add"), operands)
  println(exp.execute(globalEnvironment))
  exp = FunCall(Identifier("less"), operands)
  println(exp.execute(globalEnvironment))
  exp = FunCall(Identifier("mul"), operands)
  println(exp.execute(globalEnvironment))
}
/*
13
true
42
 */