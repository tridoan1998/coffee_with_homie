package test

import context.alu
import expression.Identifier
import value.{Boole, Chars, Exact, InExact}

object testALU extends App {
  try {
    println("ADD:",alu.execute(Identifier("add"), List(Exact(5), Exact(6), Exact(7))))     // 18
    println("ADD:",alu.execute(Identifier("add"), List(Exact(5), Exact(6), InExact(7))))     // 18
    println("ADD:",alu.execute(Identifier("add"), List(Chars("abc"), Exact(6), Exact(7)))) // abc67

    println("MULT:",alu.execute(Identifier("mul"), List(Exact(5),InExact(7))))     // 35 INEXACT

    println("MULT:",alu.execute(Identifier("mul"), List(Exact(5),Exact(7))))     // 35 EXACT


//    println("MULT:",alu.execute(identifier("mul"), List(Chars("abc"),Exact(3)))) // ERROR


//    println("SUB:",alu.execute(identifier("sub"), List(Chars("abc"), Exact(6), Exact(7)))) // error

    println("SUB:",alu.execute(Identifier("sub"),List( Exact(6), Exact(7))))

    println("SUB:",alu.execute(Identifier("sub"),List( Exact(7), Exact(6))))


    println("DIV:",alu.execute(Identifier("div"),List( Exact(7), Exact(6))))


    println("DIV:",alu.execute(Identifier("div"),List( Exact(7), InExact(6))))

//    println("ERROR DIV:",alu.execute(identifier("div"),List( Exact(7), InExact(0)))) //ERROR

    println("LESS:",alu.execute(Identifier("less"), List(Chars("abc"), Chars("def"))))  // true
    println("SAME:",alu.execute(Identifier("same"), List(Chars("abc"), Chars("abc"))))  // true


    println("LESS:",alu.execute(Identifier("less"), List(InExact(5), Exact(3))))  // true

    println("NOT SAME:",alu.execute(Identifier("unequals"), List(Chars("abc"), Chars("abc"))))  // true

//    println("NOT:",alu.execute(identifier("not"),List(Chars("abc"))))
    println("NOT",alu.execute(Identifier("not"),List(Boole(false))))



  } catch {
    case e: Exception => println(e)
  }


}

/*

"C:\Program Files\Java\jdk-9.0.4\bin\java.exe" "-javaagent:C:\Program Files\JetBrains\IntelliJ IDEA 2020.3.2\lib\idea_rt.jar=59423:C:\Program Files\JetBrains\IntelliJ IDEA 2020.3.2\bin" -Dfile.encoding=UTF-8 -classpath C:\Users\belik\IdeaProjects\Jedi0.0\out\production\Jedi0.0;C:\Users\belik\.ivy2\cache\org.scala-lang\scala-library\jars\scala-library-2.13.4.jar;C:\Users\belik\.ivy2\cache\org.scala-lang\scala-reflect\jars\scala-reflect-2.13.4.jar;C:\Users\belik\.ivy2\cache\org.scala-lang\scala-library\srcs\scala-library-2.13.4-sources.jar test.testALU
(ADD:,18)
(ADD:,18.0)
(ADD:,abc67)
(MULT:,35.0)
(MULT:,35)
(SUB:,-1)
(SUB:,1)
(DIV:,1)
(DIV:,1.1666666666666667)
(LESS:,true)
(SAME:,true)
(LESS:,false)
(NOT SAME:,false)
(NOT:,true)

Process finished with exit code 0

 */