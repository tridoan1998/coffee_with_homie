package test


import expression._
import context._
import value._


object FunCallTest extends App {
  val globalEnvironment = new Environment
  val operands = List(Exact(6),Exact(7))
  var exp = FunCall(Identifier("add"),operands)
  println(exp.execute(globalEnvironment))
  exp = FunCall(Identifier("less"),operands)
  println(exp.execute(globalEnvironment))
  exp = FunCall(Identifier("mul"),operands)
  println(exp.execute(globalEnvironment))
}

/*
text file test

"C:\Program Files\Java\jdk-9.0.4\bin\java.exe" "-javaagent:C:\Program Files\JetBrains\IntelliJ IDEA 2020.3.2\lib\idea_rt.jar=63654:C:\Program Files\JetBrains\IntelliJ IDEA 2020.3.2\bin" -Dfile.encoding=UTF-8 -classpath C:\Users\belik\IdeaProjects\Jedi0.0\out\production\Jedi0.0;C:\Users\belik\.ivy2\cache\org.scala-lang\scala-library\jars\scala-library-2.13.4.jar;C:\Users\belik\.ivy2\cache\org.scala-lang\scala-reflect\jars\scala-reflect-2.13.4.jar;C:\Users\belik\.ivy2\cache\org.scala-lang\scala-library\srcs\scala-library-2.13.4-sources.jar;C:\Users\belik\Downloads\scala-parser-combinators_2.13-1.1.2.jar SOP.console jedi1tests
-> def sum = add(mul(3, 4), sub(9, 1))
done
-> sum
20
-> 3 * 4 + 9
21
-> 3 * (4 + 9)
39
-> add(3, 4.0)
7.0
-> sub(3, 4)
-1
-> sub(3, -4)
7
-> 3 - -4
7
-> def pi = 3.14
done
-> def e = 2.7
done
-> pi * e + sum
28
-> 3 < 4
true
-> 3 == 4
false
-> 3 != 4
true
-> 3 + (if(sum < 19) 8 else 3)
6
-> if (sum < 19) nada else 3
3
-> 3 < 4 && 1 + 1 == 2 && sum < 19 && nada
true
-> 4 < 3 || 1 + 1 != 2 || sum < 19 ||  true || nada
true
bye

Process finished with exit code 0



 */