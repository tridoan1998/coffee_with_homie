package value

import expression.Literal
//a trait that is one of the values we will be using for arithmetic operations
trait Addable extends Literal {
  def +(other:Value):Addable
}
