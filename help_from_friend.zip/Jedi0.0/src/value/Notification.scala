package value

  class Notification(val message:String) extends Value {
  override def toString = message
 }
object Notification {
 def apply(message:String) = new Notification(message)
 def OK = Notification("ok")
 def DONE = Notification("done")
 def UNSPECIFIED = Notification("unspecified")
}
