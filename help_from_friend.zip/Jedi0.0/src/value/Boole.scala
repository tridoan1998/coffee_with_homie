package value


import context.{Environment, TypeException}
import expression._

case class Boole(var value:Boolean) extends Literal{
  override def execute(env: Environment): Value = this
  //AND OPERATOR
  def &&(other:Value):Boole = other match {
    case x: Boole => Boole(this.value && other.toString().toBoolean)
  }
  //OR OPERATOR
  def ||(other:Value):Boole = other match {
    case x: Boole => Boole(this.value || other.toString().toBoolean)
  }
//  def unary_!
  def unary_!():Boole = Boole(!this.value)
  //override toString
  override def toString = this.value.toString;

  override def equals(other: Any): Boolean = other match{
    case x: Boole => x.isInstanceOf[Boole] && x.value == this.value
    case _ => throw new TypeException("Must be comparable!")
  }
}

object Boole {
  val FALSE = Boole(false)
  val TRUE = Boole(true)
}
