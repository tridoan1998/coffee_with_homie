package value
import context.{Environment, TypeException}

//Add String to Things
 case class Chars(var value:String) extends Addable with Ordered[Value]{

  override def compare(other: Value): Int = other match {
   case x: Chars => this.value.compare(other.toString)
   case  _=> throw new TypeException("Must be comparable")
  }

  override def execute(env: Environment): Value = this
  override def toString = value;
 override def equals(other:Any): Boolean = other match {
  case x: Chars => x.isInstanceOf[Chars] && x.value == this.value
  case _ => throw new TypeException("Must be comparable")
 }
 //chars needs a + method
 //chars might need a * method
 override def hashCode = this.toString.##
  def size(): Exact = Exact(this.value.size)
  def subChars(to:Exact,from:Exact) = Chars( this.value.substring(to.value,from.value))

 override def +(other: Value): Addable =  Chars(this.value + other.toString)
}
