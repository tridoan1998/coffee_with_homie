package value
//what the expression produces
trait Value
