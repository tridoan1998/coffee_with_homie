package value

import context.Environment
import expression.Literal
import context.{IllegalValueException,TypeException}

case class Exact(var value:Int) extends Numeric with Ordered[Value] with Addable {

  def +(other:Value): Addable = other match {

   case x: Exact => Exact(this.value + x.value)
   case x: InExact => InExact(this.value.toDouble + x.value)
   case _ => throw new TypeException("Numeric operand required")
 }
 def *(other:Value):Numeric = other match {
   case x: Exact => Exact(this.value * x.value)
   case x: InExact => InExact(this.value.toDouble * x.value)
case _ => throw new TypeException("Numeric operand required")
 }
  /*
  check for unary or something???
  negatives
   */
  def -(other:Value):Numeric = other match {
    case x: Exact => Exact(this.value - x.value)
    case x: InExact => InExact(this.value.toDouble - x.value)
    case _ => throw new TypeException("Numeric operand required")
  }
  def /(other:Value):Numeric = other match {
    case x: Exact => if(x.value == 0) throw new IllegalValueException("Divide by Zero Exception") else Exact(this.value / x.value)
    case x:InExact => if(x.value == 0) throw new IllegalValueException("Divide by Zero Exception") else InExact(this.value / x.value)
  }

  def unary_-(): Numeric = Exact(-this.value)

  override def compare(other: Value): Int =  other match {
    case x: Exact => this.value.compare(x.value)
    case x: InExact => this.value.toDouble.compare(x.value)
    case _ => throw new TypeException("Arguments must be comparable")
  }
  override def equals(other:Any):Boolean = other match {
    case x: InExact => x.isInstanceOf[InExact] && x.value == this.value.toDouble
    case x: Exact => x.isInstanceOf[Exact] && x.value == this.value
    case _ => throw new TypeException("Arguments must be comparable")
  }
  override def toString = this.value.toString

  override def execute(env: Environment): Value = this
}

/*
Exact is Jedi's version of integers and floating point numbers.
 */