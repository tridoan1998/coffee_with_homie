package value

import context.{Environment, IllegalValueException, TypeException}
import expression.Literal

 case class InExact(var value:Double) extends Numeric with Ordered[Value] with Addable {
  def +(other:Value):Addable = other match {
   case x: Exact => Exact(this.value.toInt + x.value)
   case x: InExact => InExact(this.value + x.value)
   case _ => throw new TypeException("Addable operand required")
  }
  def *(other:Value):Numeric = other match {
   case x: Exact => Exact(this.value.toInt * x.value)
   case x:InExact => InExact(this.value * x.value);
   case _ => throw new TypeException("Numeric operand required")
  }
  def -(other:Value):Numeric = other match {
   case x: Exact =>Exact(this.value.toInt - x.value)
   case x: InExact => InExact(this.value - x.value);
   case _ => throw new TypeException("Numeric operand required")
  }
  def /(other:Value):Numeric = other match {
   case x: Exact => if(x.value == 0) throw new IllegalValueException("Divide by Zero Exception") else Exact(this.value.toInt / x.value)
   case x:InExact => if(x.value == 0) throw new IllegalValueException("Divide by Zero Exception") else InExact(this.value / x.value)
  }
  def unary_-(): Numeric = InExact(-this.value)

  //hashcode
  override def hashCode = this.toString.##


  override def execute(env: Environment): Value = this
 // < , > operators
  override def compare(other: Value): Int = other match {
   case x: Exact => this.value.toInt.compare(x.value)
   case x: InExact => this.value.compare(x.value)
   case _ => throw new TypeException("Must be comparable")
  }
  // == operator
  override def equals(other: Any): Boolean = other match{
   case x: InExact => x.isInstanceOf[InExact] && x.value == this.value
   case x: Exact => x.isInstanceOf[Exact] && x.value == this.value.toInt
   case _ => throw new TypeException("Must be comparable")
  }
//toString
  override def toString = this.value.toString
 }




//Jedi's verison if integers and floating point numbers

