package expression
import context.{Environment, alu}
import value.Value

case class FunCall( operator:Identifier, operands:List[Expression]) extends Expression {
  override def execute(env: Environment): Value = {
    {
      //turns the list of expressions into a list of values
      val args:List[Value] = operands.map(_.execute(env))
      try
        {
          alu.execute(operator,args)
        }
    }

  }
}
