package expression
import context.Environment
import value.{Notification, Value}

case class Declaration(identifier:Identifier,expression:Expression) extends SpecialForm with Expression {
  def execute(env: Environment): Value = {
    val result = expression.execute(env)
    env.put(identifier, result)
  Notification.DONE
  }
}
