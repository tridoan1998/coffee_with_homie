package expression
import context.Environment
import value._
/*

Literal calls upon itself and encapsulates Scala values such as Int,Boolean, Char ,Double, String
-inherits expression and value
 */
trait Literal extends Expression with Value {
    def execute(env:Environment): Value = this
}