package expression
import context.Environment
import value.{Boole, Notification, Value}

case class Conditional(val condition:Expression,val consequent:Expression,val alternative:Expression = null) extends SpecialForm with Expression{
  override def execute(env: Environment): Value = {
    var result = true
    if(condition.execute(env) == Boole(true))
      {
        consequent.execute(env)
      }
      else {  if(alternative == null) Notification.UNSPECIFIED else alternative.execute(env)
    }
  }
}
