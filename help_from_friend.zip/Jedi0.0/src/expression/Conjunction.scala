package expression
import context.{Environment, TypeException}
import value.{Boole, Value}

case class Conjunction(val operands:List[Expression]) extends SpecialForm with Expression {
  override def execute(env: Environment): Value = {
    //loop through the list of expression
    // uses a form of lazy execution: executes operands from left to right until answer is known
    var result = true
    for(exp<- operands if !result) {
      {
        val arg = exp.execute(env)
      if(!arg.isInstanceOf[Boole]) throw new TypeException("Conjunction operands must be of type Boole!")
        //if the && returns a false value, set result to false else true
        if(arg == Boole(false)) result = arg.asInstanceOf[Boole].value
      }

    }
    Boole(result)
  }
}
