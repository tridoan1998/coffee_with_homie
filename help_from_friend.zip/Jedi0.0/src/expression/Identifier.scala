package expression
import context.{Environment, IllegalValueException, TypeException}
import value._
//the string will be an expression
case class Identifier(val name:String) extends Expression {
//  override def toString = name

  /*

  this: keyword used to represent the contstructor of a class
    ex: this = identifier(name:String)

   */
  def hashcode = this.toString.hashCode;


  /*

  Let's put ti this way:
      Environment: a hash map
      env is a variable of Environment

      Environment is currently empty and is empty for this assignment
      The environment stores the identifier as a key-value pair
      what is my execute code doing?
        -my execute code takes in an environment
        -i check if the identifier i am passing in

   */
  override def execute(env: Environment) = env(this) match  {
    case v:Value => v
    case _ => throw new IllegalValueException("Undefined Identifier")
  }


//  = env(this) match {
//    case v: value => v
//    case _ => throw new IllegalValueException()
//  }

//    if(env(identifier(name)) == v) v else throw new IllegalValueException()
//    env(this) match {
//    //check if the result from the environment produces an output of value else throw an IllegalValueException
//    case v:value => v
//    case _ => throw new IllegalValueException()
//
//  }
}


