package expression
import context.{Environment, TypeException}
import value.{Boole, Value}

case class Disjunction(val operands:List[Expression]) extends SpecialForm with Expression{
  override def execute(env: Environment): Value = {
    var result = false;
    for(exp <- operands if !result) {
      {
        val arg = exp.execute(env)
        if(!arg.isInstanceOf[Boole]) throw new TypeException("DisJunction operands must be of type Boole!")
        if(arg == Boole(true)) result = arg.asInstanceOf[Boole].value
      }
    }
    Boole(result)
  }
}
