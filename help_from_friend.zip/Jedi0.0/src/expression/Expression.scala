package expression
import context.Environment
import value.Value

trait Expression {
  /*

  we make a trait called an expression which outputs a value and takes in for a parameter an environment

   */
  def execute(env:Environment):Value
}
