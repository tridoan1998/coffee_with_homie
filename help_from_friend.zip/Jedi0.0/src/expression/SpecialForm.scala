package expression

trait SpecialForm extends Expression