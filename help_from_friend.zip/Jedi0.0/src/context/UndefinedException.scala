package context

import expression.Identifier

class UndefinedException(val name:Identifier) extends JediException ("Undefined identifier:" + name)