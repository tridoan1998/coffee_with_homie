package context

class TypeException(gripe:String = "Type Error:") extends JediException(gripe)