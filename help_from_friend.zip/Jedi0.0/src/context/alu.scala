package context

import expression.Identifier
import value.{Addable, Boole, Chars, Numeric, Value}

/*

Arithmetic logic unit: used for performing mathematical calculations
 */
object alu {
//
  def execute(opcode: Identifier, args: List[Value]): Value = opcode.name match {
    case "add" => add(args)              // n-ary
    case "mul" => mul(args)            // n-ary
    case "sub" => sub(args)            // n-ary
    case "div" => div(args)            // n-ary
    case "less" => less(args)          // binary
    case "same" => same(args)
    case "equals" => same(args)        // binary
    case "more" => more(args)          // binary
    case "unequals" => unequals(args)  // binary
    case "not" => not(args)            // unary
  }

  private def add(args: List[Value]): Value = {

    def helper(result: Addable, unseen: List[Value]): Addable =
      if(unseen == Nil) result
      else helper(result + unseen.head, unseen.tail)

    if(args.size < 2) throw new TypeException("2 or more inputs required by +")
    args(0) match {
      case n: Addable => helper(args(0).asInstanceOf[Addable], args.tail )
      case _ => throw new TypeException("Inputs to + must be addable")
    }
  }
  private def mul(args:List[Value]): Value = {
    def helper(result:Numeric, unseen:List[Value]): Addable =
      if(unseen == Nil) result
      else helper(result * unseen.head,unseen.tail)
  if(args.size < 2) throw new TypeException("2 or more inputs required by  *")
    args(0) match {
      case n: Numeric => helper(args(0).asInstanceOf[Numeric],args.tail)
      case _ => throw new TypeException("Inputs to * must be numeric")
    }

  }
  private def sub(args:List[Value]): Value = {
    def helper(result:Numeric, unseen:List[Value]):Numeric =
      if(unseen == Nil) result
      else helper(result - unseen.head,unseen.tail)
    if(args.size < 2) throw new TypeException("2 or more inputs required by  -")
    args(0) match {
      case n: Numeric => helper(args(0).asInstanceOf[Numeric],args.tail)
      case _ => throw new TypeException("Inputs to - must be numeric")
    }
  }
  private def div(args:List[Value]) : Value = {
    def helper(result:Numeric, unseen:List[Value]):Numeric =
      if(unseen == Nil) result
      else helper(result / unseen.head,unseen.tail)
    if(args.size < 2) throw new TypeException("2 or more inputs required by  /")
    args(0) match {
      case n: Numeric => helper(args(0).asInstanceOf[Numeric],args.tail)
      case _ => throw new TypeException("Inputs to / must be numeric")
    }
  }

  private def less(args: List[Value]): Value = {
    if(args.size != 2) throw new TypeException("2 inputs required by <")
    if(!args(0).isInstanceOf[Ordered[Value]]) throw new TypeException("Inputs to < must be comparable")
    Boole(args(0).asInstanceOf[Ordered[Value]] < args(1))
  }
  private def same(args:List[Value]): Value =  {
     if(args.length != 2) throw new TypeException("2 inputs required by ==")
      Boole(args(0).equals(args(1)))
  }
  private def equals(args:List[Value]): Value = {
      same(args)
  }
  private def more(args:List[Value]):Value = {
    if(args.size != 2) throw new TypeException("2 inputs required by >")
    if(!args(0).isInstanceOf[Ordered[Value]]) throw new TypeException("Inputs to > must be comparable")
    Boole(args(0).asInstanceOf[Ordered[Value]] > args(1))
  }

  private def unequals(args:List[Value]): Value =  {
    if(args.length != 2) throw new TypeException("2 inputs required by !=")
    !(equals(args).asInstanceOf[Boole])
//    Boole(!args(0).equals(args(1)))
  }

  //ASK THE PROFESSOR

  private def not(args:List[Value]): Value = {
    if(args.length != 1) throw new TypeException("1 input required by !=")
  if(args(0).isInstanceOf[Boole]){
        if(args(0) == Boole(true) ) Boole(false)
        else Boole(true)
  }
  else throw new TypeException("Not a Boole")
  }



}

/*

def not(args:List[Value]): Value = {

-> (x < y ) => not(true) => alu.execute(Identifier("not"),List[true])

  1. args.size != 1, throw new exception

  2. args(0) not Boole throw exception

  3. !(args(0).asInstance[Boole]
}
 */