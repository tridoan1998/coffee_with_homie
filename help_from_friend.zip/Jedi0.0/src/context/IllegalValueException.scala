package context

class IllegalValueException(gripe:String = "Illegal Value Error") extends JediException(gripe) {

}
