package context

class JediException(val gripe:String = "Jedi Error") extends Exception(gripe)
