package context

import expression.Identifier
import value.Value
/*

Overview:
  -in order to execute a jedi expression, a data structure that tokenizes the jedis expressions is needed. Here we use a hashMap. why? it makes the relation between identifier and value much easier
    ex: z = 4
      let's say z is some sort of identifier
       z maps to 4
       we can look up if an identifier for the value 4 exists
      so what is this Environment? let's call it a take that is a HashMap which accepts identifiers as keys mapped to a value

 */
class Environment(var extension: Environment = null) extends collection.mutable.HashMap[Identifier,Value] with Value {
  // used by closures to bind parameters to arguments
  def bulkPut(params: List[Identifier], args: List[Value]) {
    if (params.length != args.length) throw new TypeException("# arguments != #parameters")
    for(i <- 0 until params.length) this.put(params(i), args(i))
  }

  override def contains(name: Identifier): Boolean = {
    super.contains(name) || (extension != null && extension.contains(name))
  }

  override def apply(name: Identifier): Value = {
    if (super.contains(name)) super.apply(name)
    else if (extension != null) extension.apply(name)
    else throw new UndefinedException(name)
  }
}


