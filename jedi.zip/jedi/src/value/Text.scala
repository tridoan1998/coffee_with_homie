package value

import context._
import expression._

class Text(val body: Expression) extends Value{
  private var cache: Value = _
  def apply(callEnv: Environment) = {
    if(cache == null)
    {
      cache = body.execute(callEnv)
    }
    cache
  }
}
  

object Text{
  def apply(body: Expression): Text = new Text(body)
  
}