package value

/*
 * 
 *-> def pi = 3.14  // updates env(pi) = 3.14
 * 
 * ok
 */



class Notification(val name: String) extends Value {
 override def toString = name
  
  
}

object Notification{
  val Ok = new Notification("OK")
  val DONE = new Notification("DONE")
  val UNSPECIFIED = new Notification("UNSPECIFIED")
  
  def apply(name: String) = new Notification(name: String) 
}