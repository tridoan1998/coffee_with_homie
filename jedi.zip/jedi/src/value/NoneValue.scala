package value
import expression._

object NoneValue extends OptionValue with Literal{
  
  override def toString = "None"
  
}

