package value

trait OptionValue extends Value {
  
}