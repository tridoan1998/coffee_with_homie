package value

import expression._
import context._


case class Chars(val value: String) extends Literal with Ordered[Chars] with Equals{
  
  override def < (other: Chars) = this.value < other.value  
  
  def == (other: Chars) = this.value == other.value
  
  override def compare(other: Chars): Int = if (this.value < other.value) -1 else if (other.value < this.value) 1 else 0
  
  override def canEqual(other: Any) =  other.isInstanceOf[Chars]
  
  override def equals(other: Any): Boolean =
    other match {
       case other: Chars => this.canEqual(other) && (other.value == this.value)
       case _ => false
  }
  
  override def hashCode = this.toString.##
  
  def substring(x: Integer, y: Integer)= Chars(this.value.substring(x.value, y.value)) 
  
  def +(other: Chars) = Chars(this.value + other.value) 
  
  override def toString = this.value.toString
  
  //cri evertim
  
}