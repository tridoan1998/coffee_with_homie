package value

class SomeValue(var content: Value) extends OptionValue{
  override def toString = "[" + content.toString + "]"

}

object SomeValue{
  def apply(content: Value): SomeValue = new SomeValue(content)
}