package value

import context._
import expression._


class Thunk( body: Expression, defEnv: Environment) extends Closure(Nil, body, defEnv) {
  
  private var cache: Value = _
  def apply() = {
    if(cache == null)
    {
      cache = super.apply(Nil)
    }
    cache
  }
}

object Thunk{
  def apply(body: Expression, defEnv: Environment): Thunk = new Thunk(body, defEnv)
  
}