package expression

import context._
import value._

case class Block(val operands: List[Expression]) extends SpecialForm {
   def execute(env: Environment): Value = {
     val tempEnv = new Environment(env)
     operands.map(_.execute(tempEnv)).last
   }
}