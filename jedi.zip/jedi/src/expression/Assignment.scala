package expression

import context._
import value._

class Assignment(val vbl: Identifier, val update: Expression) extends SpecialForm{
  def execute(env: Environment): Value = {
    var res = vbl.execute(env)
    if(!res.isInstanceOf[Variable]) throw new TypeException("assigment: not a variable")
    
    else res.asInstanceOf[Variable].content = update.execute(env)  
    
    Notification.DONE
  }
  
}