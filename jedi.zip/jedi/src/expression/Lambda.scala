package expression

import context._
import value._

case class Lambda(val id: List[Identifier], val exp: Expression) extends SpecialForm {
  def execute(env: Environment): Value = new Closure(id, exp, env)
}