package expression

import context._
import value._

case class Iteration(val condition: Expression, val body: Expression) extends SpecialForm {
  def execute(env: Environment):  Value = {
   
    val res = condition.execute(env)
    
    if(!res.isInstanceOf[Boole]) throw new TypeException("Condition of while must be Boole")
    var cond = (res.asInstanceOf[Boole]).value
    while(cond){
      body.execute(env)
      res 
      if(cond != res) cond = !cond
    }
    Notification.DONE
  }
}