package context

import scala.util.parsing.combinator._
import expression._
import value._

class Jedi3Parsers extends Jedi2Parsers {
    
  override def expression: Parser[Expression] = declaration | conditional | iteration | disjunction | failure("Invalid expression")
  
  override def term: Parser[Expression]  = lambda | freeze | delay | funCall | block |  assignment | dereference | literal | "("~>expression<~")"
  
  
  def assignment: Parser[Expression] = identifier ~ "=" ~ expression^^{
    case id ~ "=" ~ exp => new Assignment(id, exp)
  } 
  
  def iteration: Parser[Expression] =  "while" ~ "(" ~ expression ~ ")" ~ expression^^{
    case "while" ~ "(" ~ cond ~ ")" ~ exp => new Iteration(cond, exp) 
  }
  
  // dereference ::= "[" ~ expression ~ "]"
   def dereference: Parser[Expression] = "[" ~ expression ~ "]" ^^ {
   case "[" ~ call ~ "]" => new FunCall(Identifier("dereference"), List(call))
 } 
}