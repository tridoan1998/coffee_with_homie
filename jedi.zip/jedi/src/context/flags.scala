package context


object flags {
  var paramPassing = byValue
  val byValue = 0
  val byName = 1
  val byText = 2
}