package context

import scala.util.parsing.combinator._
import expression._
import value._

class Jedi2Parsers extends Jedi1Parsers {
    
  override def term: Parser[Expression]  = lambda | freeze | delay | funCall | block | literal | "("~>expression<~")"
  
  
  def freeze: Parser[MakeThunk] = "freeze" ~ "(" ~ expression ~ ")" ^^{
   case "freeze" ~ "(" ~ expression ~ ")" => MakeThunk(expression)
  }
  
  def delay: Parser[MakeText] = "delay" ~ "(" ~ expression ~ ")"^^{
   case  "delay" ~ "(" ~ expression ~ ")" => MakeText(expression)
  }
  // params parser
  // a parameter list is zero or more comma-separated identifiers bracketed by parentheses:
  // params ::= "(" ~ (identifier ~ ("," ~ identifier)*)? ~ ")"
  def params: Parser[List[Identifier]] =  "(" ~> opt(identifier ~ rep("," ~> identifier)) <~ ")" ^^{
    case None => Nil
    case Some(e ~ Nil) => List(e)
    case Some(e ~ exps)=> e::exps
    case _=> Nil
  }
  
  
  // lambda parser
  // lambda ::= "lambda" ~ params ~ expression
  def lambda: Parser[Expression] = "lambda" ~ params ~ expression ^^{
    case "lambda" ~ par ~ exp => Lambda(par, exp)
  }
  // block parser
  // a block is one or more semi-colon separated expressions bracketed by curly braces:
  // block ::= "{" ~ expression ~ (";" ~ expression)* ~ "}"
     def block: Parser[Block] = "{" ~ expression ~ rep(";" ~> expression) ~ "}" ^^{
      case "{" ~ e ~ Nil ~"}" => Block(List(e)) 
      case "{" ~ e ~ repE ~ "}" => Block(e::repE) 
      }
  
  // override of term parser
  
}