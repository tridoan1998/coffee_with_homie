package value

import expression._

//Orderables
case class Boole (val value: Boolean) extends Literal {

  override def equals(obj: Any): Boolean = super.equals(obj)

  override def toString: String = value.toString

  override def hashCode = this.toString.##

  def unary_! = Boole(!(this.value))

  def &&(other:Value):Boole = other match {
    case x: Boole => Boole(this.value || other.toString().toBoolean)
  }

  def ||(other:Value):Boole = other match {
    case x: Boole => Boole(this.value || other.toString().toBoolean)
  }
}
object Boole {
  val FALSE = Boole(false)
  val TRUE = Boole(true)
}

/*
All of the concrete classes (Boole, Chars, Exact, and Inexact) are value classes in the sense that they need overrides of equals, toString, and hashCode.

Instances of Chars, Exact, and Inexact can be compared to other values, throwing exceptions if the other values don't make sense:

-> "abc" < "def"
true
-> "abc" == "abc"
true
-> 23 < 3.14
false
-> 2.9 < 100
true
-> 0 < true
Arguments must be comparable
 */