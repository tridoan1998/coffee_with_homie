package context

import scala.collection.mutable._
import value._
import expression._

//To make everything compile you will need to also define Environment. For now, something like this should work:
class Environment extends collection.mutable.HashMap[Identifier, Value]


